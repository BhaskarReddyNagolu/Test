INSERT INTO UserAccountDetails VALUES (1122335568, 'Sweta Y', 'S1463', 'Password@123', 'No', 11000,0,'wire');
INSERT INTO UserAccountDetails VALUES (1122335875, 'Rajasekhar', 'R2463', 'Password@123', 'Yes', 20000,235,'wire');
INSERT INTO UserAccountDetails VALUES (1122331234, 'Naveen', 'N3463', 'Password@123', 'Yes', 15000,500,'wire');
INSERT INTO UserAccountDetails VALUES (1122331235, 'Bhaskar', 'B2088', 'Password@123', 'Yes', 5000,1000,'swift');
INSERT INTO UserAccountDetails VALUES (1122331236, 'Prasanthi', 'P2088', 'Password@123', 'Yes', 50000,200,'swift');